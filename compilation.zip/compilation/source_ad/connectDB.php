<?php

$lh = 'localhost';
$db = 'rental2';
$un = 'root';
$pw = '';

?>
