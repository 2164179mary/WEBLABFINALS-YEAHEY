<?php
echo <<<_END
    <script type="text/javascript" src="../script/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="../script/script.js"></script>
_END;

require_once 'connectDB.php';
$conn = new mysqli($lh, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

$_query = "select customerID customer, spID sp, reporter, description from report";

$_result = $conn->query($_query);
if (!$_result) die($conn->error);
$_rows = $_result->num_rows;

echo "<p>Reports by Service Provider</p>";
echo "<table>";
echo <<<_END
    <tr>
        <th>Reporter</th>
        <th>Reported</th>
        <th>Description</th>
    </tr>
_END;

for( $i = 0; $i < $_rows; ++$i){
    $_result->data_seek($i);
    $_row = $_result->fetch_array(MYSQLI_ASSOC);
    $_type = $_row['reporter'];
    $_sp = $_row['sp'];
    $_customer = $_row['customer'];
    $_description = $_row['description'];


    if($_type == 'sp'){
        $_reporter = $_sp;
        $_reported = $_customer;
    }else{
        $_reporter = $_customer;
        $_reported = $_sp;
    }

    echo <<<_END
    <tr>
    <th>$_reporter</th>
    <th>$_reported</th>
    <th>$_description</th>
    </tr>
_END;
}

echo "</table>";
?>
