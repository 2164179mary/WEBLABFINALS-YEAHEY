<?php

class Report
{
    private $_reporter;
    private $_target;
    private $_description;

    public function _construct($_reporter, $_target, $_description) {
        $this->_reporter = $_reporter;
        $this->_target = $_target;
        $this->_description = $_description;
    }

    public function get_reporter(){
        return $this->_reporter;
    }

    public function get_target(){
        return $this->_target;
    }

    public function get_description(){
        return $this->_description;
    }

}

?>