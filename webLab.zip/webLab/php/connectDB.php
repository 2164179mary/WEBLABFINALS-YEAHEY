<?php

$lh = 'localhost';
$db = 'rental';
$un = 'root';
$pw = 'root';

?>